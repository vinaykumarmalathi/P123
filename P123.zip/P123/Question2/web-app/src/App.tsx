import { useState } from 'react'

import './App.css'
import ProductList from './components/ProductList';
import { Route, Routes } from 'react-router-dom';
import ProductDetails from './components/ProductDetails';

function App() {

   return (
     <Routes>
      <Route path="/" element={<ProductList />} />
      <Route path="/categories/:categoryname/products/:productid" element={<ProductDetails />} />
    </Routes>
  );
}

export default App
