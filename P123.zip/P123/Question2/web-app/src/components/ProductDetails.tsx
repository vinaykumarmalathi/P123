import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";
import type { Product } from "./product";

const ProductDetails = () => {
  const { categoryname, productid } = useParams<{ categoryname: string; productid: string }>();
  const [product, setProduct] = useState<Product | null>(null);

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const res = await axios.get<Product>(
          `http://localhost:3001/categories/${categoryname}/products/${productid}`,
          {
            params: { company: "AMZ" }, // change if dynamic company
          }
        );
        setProduct(res.data);
      } catch (err) {
        console.error("Failed to fetch product:", err);
      }
    };

    fetchProduct();
  }, [categoryname, productid]);

  if (!product) return <div>Loading...</div>;

  return (
    <div>
      <h2>Product Details</h2>
      <p><strong>Name:</strong> {product.productName}</p>
      <p><strong>Price:</strong> ₹{product.price}</p>
      <p><strong>Rating:</strong> {product.rating ?? "N/A"}</p>
      <p><strong>Discount:</strong> {product.discount ?? "0"}%</p>
      <p><strong>Availability:</strong> {product.availability}</p>
    </div>
  );
};

export default ProductDetails;
