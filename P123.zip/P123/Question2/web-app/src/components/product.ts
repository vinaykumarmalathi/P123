export interface Product {
  productName: string;
  price: number;
  rating?: number;
  discount?: number;
  availability: "yes" | "out-of-stock";
  productId?: string; 
}