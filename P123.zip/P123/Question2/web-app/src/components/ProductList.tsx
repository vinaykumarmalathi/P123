import React, { useState } from "react";
import axios from "axios";
import type { Product } from "./product";
import { Link } from "react-router-dom";

const ProductList: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [inputs, setInputs] = useState({
    company: "AMZ",
    category: "Laptop",
    top: 10,
    minPrice: 1,
    maxPrice: 10000,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setInputs((prev) => ({
      ...prev,
      [name]: ["top", "minPrice", "maxPrice"].includes(name) ? Number(value) : value,
    }));
  };

  const fetchProducts = async () => {
    try {
      const res = await axios.get<Product[]>("http://localhost:3001/categories/Laptop/products", {
        params: inputs,
      });
      setProducts(res.data);
    } catch (err) {
      console.error("Error fetching products:", err);
    }
  };

  return (
    <div>
      <h2>Top N Products</h2>
      <input name="company" value={inputs.company} onChange={handleChange} placeholder="Company" />
      <input name="category" value={inputs.category} onChange={handleChange} placeholder="Category" />
      <input type="number" name="top" value={inputs.top} onChange={handleChange} placeholder="Top N" />
      <input type="number" name="minPrice" value={inputs.minPrice} onChange={handleChange} placeholder="Min Price" />
      <input type="number" name="maxPrice" value={inputs.maxPrice} onChange={handleChange} placeholder="Max Price" />
      <button onClick={fetchProducts}>Fetch</button>

      <ul>
        {products.map((p, i) => (
          <li key={i}>
            <strong>{p.productName}</strong> — ₹{p.price} | Rating: {p.rating ?? "-"} | Discount: {p.discount ?? 0}% | Availability: {p.availability}
               <Link
                  to={`/categories/${inputs.category}/products/${p.productId}`}
                  style={{ marginLeft: "10px" }}
                >
                  View Details
                </Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ProductList;