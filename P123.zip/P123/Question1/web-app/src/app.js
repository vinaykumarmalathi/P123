const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());
const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Backend server running on http://localhost:${PORT}`);
});


const baseURL = 'http://localhost:4500/test';
let token = '';

const registerDetails = {
    "companyName" : "AMZ",
    "ownerName" : "Vikas Kumar M",
    "rollNo" : "P10345",
    "ownerEmail" : "vikas@mits.ac.in",
    "accessCode" : "vikasabcd"
};

async function getToken() {
  const authBody = {
    companyName: registerDetails.companyName,
    clientID: "37bb493c-73d3-47ea-8675-21f66ef9b735",
    clientSecret: "XYOjLORPasKM04AN",
    ownerName: registerDetails.ownerName,
    ownerEmail: registerDetails.ownerEmail,
    rollNo: registerDetails.rollNo
  };

  const response = await axios.post(`${baseURL}/auth`, authBody);
  token = response.data.access_token;

}

app.get('/categories/:categoryname/products', async (req, res) => {

  const { company, category, top, minPrice, maxPrice } = req.query;

  try {
    if (!token) await getToken();
    //server url
    const url = `${baseURL}/companies/${company}/categories/${category}/products?top=${top}&minPrice=${minPrice}&maxPrice=${maxPrice}`;
    console.log(url);
    const response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    res.json(response.data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/categories/:categoryname/products/:productid', async (req, res) => {
  const { categoryname, productid } = req.params;

  const company = req.query.company || 'AMZ';

  try {
    if (!token) await getToken();

    //server url
    const url = `${baseURL}/companies/${company}/categories/${categoryname}/products/${productid}`;
    console.log(url);
    const response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    res.json(response.data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
