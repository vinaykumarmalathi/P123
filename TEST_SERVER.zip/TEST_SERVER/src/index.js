const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());
app.listen(4500)

const registerDate = [];
const accessCode = "vikasabcd"

const randomString = (len) => [...Array(len)].map(() => 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'.charAt(Math.floor(Math.random() * 62))).join('');


app.post('/test/register' , (req, res) => {
    if(req.body.accessCode ===  accessCode) {
        registerDate.push(req.body);

        const reqBody = req.body;

        const resBody = {
            companyName: reqBody.companyName,
            clientId: randomString(12),
            clientScret: randomString(32),
            ownerName: reqBody.ownerName,
            ownerEmail: reqBody.ownerEmail,
            rollNo: reqBody.rollNo,
        }
        res.send(resBody);

    } else {
        res.send({error: "Invalid access code" })
    }
});


app.post('/test/auth' , (req, res) => {
    res.send({
        "token-type": "Bearer",
        "access_token": randomString(256)
        })
});

const products=[
    {
        "productId": 1,
        "productName":"Laptop 1",
        "price" : 2236,
        "rating" : 4.7,
        "discount" : 63,
        "availability" : "yes"
    },
    {
        "productId": 2,
        "productName":"Laptop 2",
        "price" : 2236,
        "rating" : 4.7,
        "discount" : 63,
        "availability" : "yes"
    },
    {
        "productId": 3,
        "productName":"Laptop 3",
        "price" : 2236,
        "rating" : 4.7,
        "discount" : 63,
        "availability" : "yes"
    },
    {
        "productId": 4,
        "productName":"Laptop 4",
        "price" : 2236,
        "rating" : 4.7,
        "discount" : 63,
        "availability" : "yes"
    },
    {
        "productId": 5,
        "productName":"Laptop 5",
        "price" : 2236,
        "rating" : 4.7,
        "discount" : 63,
        "availability" : "yes"
    }
]

app.get('/test/companies/:companyname/categories/:categoryname/products' , (req, res) => {
    
    const top = req.query.top;
    const minPrize = req.query.minPrize;
    const maxPrize = req.query.minPrize;

    res.send(products);
});

app.get('/test/companies/:companyname/categories/:categoryname/products/:productId' , (req, res) => {

    const product =  products.find(product => product.productId == req.params.productId);

    res.send(product);
});